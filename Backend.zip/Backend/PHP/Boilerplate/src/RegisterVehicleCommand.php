<?php

namespace Fulll;

class RegisterVehicleCommand extends Command
{
    protected static $defaultName = 'fleet register-vehicle';

    private $fleetManager;

    public function __construct(FleetManager $fleetManager)
    {
        parent::__construct();

        $this->fleetManager = $fleetManager;
    }

    protected function configure()
    {
        $this->addArgument('fleetId', InputArgument::REQUIRED, 'Fleet ID');
        $this->addArgument('vehiclePlateNumber', InputArgument::REQUIRED, 'Vehicle Plate Number');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $fleetId = $input->getArgument('fleetId');
        $vehiclePlateNumber = $input->getArgument('vehiclePlateNumber');

        $this->fleetManager->registerVehicle($fleetId, $vehiclePlateNumber);

        $output->writeln("Vehicle registered successfully in fleet $fleetId");

        return Command::SUCCESS;
    }
}
