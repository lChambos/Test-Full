<?php

namespace Fulll;

class Vehicle
{
    private $id;
    private $fleetId;
    private $plateNumber;
    private $location;

    public function __construct($id, $fleetId)
    {
        $this->id = $id;
        $this->fleetId = $fleetId;
        $this->plateNumber = $plateNumber;
    }

    public function getId()
    {
        return $this->id;
    }

    public function getFleetId()
    {
        return $this->fleetId;
    }

    public function getPlateNumber()
    {
        return $this->plateNumber;
    }

    public function localize($lat, $lng, $alt = null)
    {
        $this->location = ['lat' => $lat, 'lng' => $lng, 'alt' => $alt];
    }

    public function getLocation()
    {
        return $this->location;
    }
}
