<?php

namespace Fulll;

class Fleet
{
    private $id;
    private $userId;
    private $vehicles = [];

    public function __construct($id, $userId)
    {
        $this->id = $id;
        $this->userId = $userId;
    }

    public function getId()
    {
        return $this->id;
    }

    public function getUserId()
    {
        return $this->userId;
    }

    public function registerVehicle(Vehicle $vehicle)
    {
        $plateNumber = $vehicle->getPlateNumber();

        if (isset($this->vehicles[$plateNumber])) {
            throw new \Exception("Vehicle with plate number $plateNumber is already registered in the fleet.");
        }

        $this->vehicles[$plateNumber] = $vehicle;
    }

    public function getVehicle($plateNumber)
    {
        if (!isset($this->vehicles[$plateNumber])) {
            throw new \Exception("Vehicle with plate number $plateNumber not found in the fleet.");
        }

        return $this->vehicles[$plateNumber];
    }
}
