<?php

namespace Fulll\entity;

class Vehicle
{
    private int $id;
    private int $fleetId;
    private string $plateNumber;
    private $location;

    public function __construct($id, $fleetId, $plateNumber)
    {
        $this->id = $id;
        $this->fleetId = $fleetId;
        $this->plateNumber = $plateNumber;
    }

    public function getId(): int
    {
        return $this->id;
    }

    public function getFleetId(): int
    {
        return $this->fleetId;
    }

    public function getPlateNumber(): string
    {
        return $this->plateNumber;
    }

    public function localize($lat, $lng, $alt = null)
    {
        $this->location = ['lat' => $lat, 'lng' => $lng, 'alt' => $alt];
    }

    public function getLocation()
    {
        return $this->location;
    }
}
