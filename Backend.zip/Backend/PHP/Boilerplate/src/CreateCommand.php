<?php

namespace Fulll;



class CreateCommand extends Command
{
    protected static $defaultName = 'fleet create';

    private $fleetManager;

    public function __construct(FleetManager $fleetManager)
    {
        parent::__construct();

        $this->fleetManager = $fleetManager;
    }

    protected function configure()
    {
        $this->addArgument('userId', InputArgument::REQUIRED, 'User ID');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $userId = $input->getArgument('userId');
        $fleetId = $this->fleetManager->createFleet($userId);

        $output->writeln("Fleet created with ID: $fleetId");

        return Command::SUCCESS;
    }
}
