<?php

namespace Fleet;

class FleetRepository
{
    private $fleets = [];

    public function createFleet($userId)
    {
        $fleetId = uniqid();
        $this->fleets[$fleetId] = new Fleet($fleetId, $userId);

        return $fleetId;
    }

    public function getFleet($fleetId)
    {
        if (!isset($this->fleets[$fleetId])) {
            throw new \Exception("Fleet with ID $fleetId not found.");
        }

        return $this->fleets[$fleetId];
    }

    public function saveFleet(Fleet $fleet)
    {
        $this->fleets[$fleet->getId()] = $fleet;
    }
}
