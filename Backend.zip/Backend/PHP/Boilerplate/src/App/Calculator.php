<?php

declare(strict_types=1);

namespace Fulll\App;

class Calculator
{
    public function multiply(int $a, int $b): int
    {
        return $a * $b;
    }
}
