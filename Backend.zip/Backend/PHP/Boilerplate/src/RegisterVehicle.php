<?php

namespace Fulll;

class RegisterVehicle
{
    public function VehicleRegister()
    {
        $fleetManager = new FleetManager();
        $vehicle = new Vehicle('123', 'fleet1');

        $fleetManager->registerVehicle($vehicle);

        $this->assertTrue(true);
    }
}
