<?php

namespace Fulll\Repository;

use Fulll\entity\Fleet;

class FleetRepository
{
    private array $fleets = [];

    public function createFleet($userId): string
    {
        $fleetId = uniqid('fleet-', true);
        $this->fleets[$fleetId] = new Fleet($fleetId, $userId);

        return $fleetId;
    }

    public function getFleet($fleetId)
    {
        if (!isset($this->fleets[$fleetId])) {
            throw new \Exception("Fleet with ID $fleetId not found.");
        }

        return $this->fleets[$fleetId];
    }

    public function saveFleet(Fleet $fleet)
    {
        $this->fleets[$fleet->getId()] = $fleet;
    }

    public function getFleetById(int $fleetId) {
        foreach ($this->fleets as $fleet) {
            if ($fleet->getId() === $fleetId) {
                return $fleet;
            }
        }
    }
}
