<?php

namespace Fulll;


class LocalizeVehicleCommand extends Command
{
    protected static $defaultName = 'fleet localize-vehicle';

    private $fleetManager;

    public function __construct(FleetManager $fleetManager)
    {
        parent::__construct();

        $this->fleetManager = $fleetManager;
    }

    protected function configure()
    {
        $this->addArgument('fleetId', InputArgument::REQUIRED, 'Fleet ID');
        $this->addArgument('vehiclePlateNumber', InputArgument::REQUIRED, 'Vehicle Plate Number');
        $this->addArgument('lat', InputArgument::REQUIRED, 'Latitude');
        $this->addArgument('lng', InputArgument::REQUIRED, 'Longitude');
        $this->addArgument('alt', InputArgument::OPTIONAL, 'Altitude');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $fleetId = $input->getArgument('fleetId');
        $vehiclePlateNumber = $input->getArgument('vehiclePlateNumber');
        $lat = $input->getArgument('lat');
        $lng = $input->getArgument('lng');
        $alt = $input->getArgument('alt');

        $this->fleetManager->localizeVehicle($fleetId, $vehiclePlateNumber, $lat, $lng, $alt);

        $output->writeln("Vehicle localized successfully in fleet $fleetId");

        return Command::SUCCESS;
    }
}
