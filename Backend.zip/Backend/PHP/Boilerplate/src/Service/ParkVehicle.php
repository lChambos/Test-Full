<?php

namespace Fulll\Service;


use Fulll\entity\Vehicle;
use Fulll\Repository\FleetRepository;

class ParkVehicle
{

    public function __construct(FleetRepository $repository)
    {
        $this->fleetRepository = $repository;
    }

    /**
     * @throws \Exception
     */
    public function VehiclePark(): void
    {
        $fleetManager = new FleetManager();

        // On créé le véhicule
        $vehicle = new Vehicle(1, 1, 'AK-132-PR');
        // On récupère la flotte
        $fleet = $this->fleetRepository->getFleetById(1);
        // On l'enregistre
        $fleetManager->registerVehicle($vehicle, $fleet);
        // On le gare
        $result = $fleetManager->parkVehicle($vehicle, 'GPS Coordinates');

        $this->assertTrue($result);
    }
}
