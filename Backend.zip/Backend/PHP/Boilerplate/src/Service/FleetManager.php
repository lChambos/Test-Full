<?php

namespace Fulll\Service;

use Exception;
use Fulll\entity\Fleet;
use Fulll\entity\Vehicle;
use Fulll\Repository\FleetRepository;

class FleetManager
{
    private array $fleets = [];
    private $repository;

    public function __construct(FleetRepository $repository)
    {
        $this->repository = $repository;
    }

    public function createFleet($userId): string
    {
        return $this->repository->createFleet($userId);
    }

    /**
     * @throws Exception
     */
    public function localizeVehicle($fleetId, $vehiclePlateNumber, $lat, $lng, $alt = null): void
    {
        $fleet = $this->repository->getFleet($fleetId);
        $vehicle = $fleet->getVehicle($vehiclePlateNumber);

        $vehicle->localize($lat, $lng, $alt);

        $this->repository->saveFleet($fleet);
    }

    /**
     * @throws Exception
     */
    public function registerVehicle(Vehicle $vehicle, Fleet $fleet): void
    {
        foreach ($fleet->getVehicles() as $fleetVehicle) {
            if ($fleetVehicle === $vehicle) {
                throw new Exception('Vehicle with ID'. $vehicle->getId(). 'is already registered.');
            }

            $this->fleets[$vehicle->getId()] = $vehicle;
        }
    }

    public function parkVehicle(Vehicle $vehicle, $location): bool
    {
        $vehicleId = $vehicle->getId();

        if (!isset($this->fleets[$vehicleId])) {
            throw new Exception("Vehicle with ID $vehicleId is not registered.");
        }

        return true;
    }
}
