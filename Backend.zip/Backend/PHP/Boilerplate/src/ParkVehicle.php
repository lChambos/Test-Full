<?php

namespace Fulll;


class ParkVehicle
{
    public function VehiclePark()
    {
        $fleetManager = new FleetManager();
        $vehicle = new Vehicle('123', 'fleet1');
        $fleetManager->registerVehicle($vehicle);

        $result = $fleetManager->parkVehicle($vehicle, 'GPS Coordinates');

        $this->assertTrue($result);
    }
}
