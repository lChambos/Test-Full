<?php

namespace Fulll;

class FleetManager
{
    private $fleet = [];
    private $repository;

    public function __construct(FleetRepository $repository)
    {
        $this->repository = $repository;
    }

    public function createFleet($userId)
    {
        $fleetId = $this->repository->createFleet($userId);

        return $fleetId;
    }

    public function localizeVehicle($fleetId, $vehiclePlateNumber, $lat, $lng, $alt = null)
    {
        $fleet = $this->repository->getFleet($fleetId);
        $vehicle = $fleet->getVehicle($vehiclePlateNumber);

        $vehicle->localize($lat, $lng, $alt);

        $this->repository->saveFleet($fleet);
    }


    public function registerVehicle(Vehicle $vehicle)
    {
        $vehicleId = $vehicle->getId();

        if (isset($this->fleet[$vehicleId])) {
            throw new Exception("Vehicle with ID $vehicleId is already registered.");
        }

        $this->fleet[$vehicleId] = $vehicle;
    }

//    public function registerVehicle($fleetId, $vehiclePlateNumber)
//    {
//        $fleet = $this->repository->getFleet($fleetId);
//        $vehicle = new Vehicle($vehiclePlateNumber, $fleetId);
//
//        $fleet->registerVehicle($vehicle);
//
//        $this->repository->saveFleet($fleet);
//    }

    public function parkVehicle(Vehicle $vehicle, $location)
    {
        $vehicleId = $vehicle->getId();

        if (!isset($this->fleet[$vehicleId])) {
            throw new Exception("Vehicle with ID $vehicleId is not registered.");
        }

        return true;
    }
}
